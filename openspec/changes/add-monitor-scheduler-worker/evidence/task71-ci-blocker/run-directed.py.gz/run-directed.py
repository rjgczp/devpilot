import sys,json,subprocess
from pathlib import Path
repo=Path('/Users/sansea/Documents/ChatGPT/devpilot');sys.path.insert(0,str(repo/'tests/scheduler'))
from joint_fixture import JointHarness
class Directed(JointHarness):
 def pg_test_name(self):return '^TestCheckpointOneStartExpiryAfterFinalWait$'
 def pg_completion(self,mode,status):
  assert not self.events() and self.life is None
  return dict(test='TestCheckpointOneStartExpiryAfterFinalWait',mode=mode,exit_code=status,target_tcp=0,probe=False)
base=Path('/private/tmp/devpilot-result71');tools=base/'tools';evidence=base/'ci-blocker/directed';evidence.mkdir(exist_ok=False)
for mode in ['normal','race']:
 h=Directed(evidence/mode,tools/'networksupervisorfixture',tools/'schedulerprobefixture','expiry-only',mode);code=1
 try:h.pg(tools/('expiry-pg-race.test' if mode=='race' else 'expiry-pg.test'),mode);code=0
 finally:h.record('directed-result',dict(mode=mode,exit_code=code,timeout_ms=250,authorization_fixture_ms=200));h.close()
