from pathlib import Path
import json,hashlib,subprocess,shutil,difflib
repo=Path('/Users/sansea/Documents/ChatGPT/devpilot');out=Path('/private/tmp/devpilot-joint63-nscd-review')
hashof=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
run=Path('/private/tmp/devpilot-joint63-nscd-matrix');dev=Path('/private/tmp/devpilot-joint63-nscd-development');diag=Path('/private/tmp/devpilot-joint63-nscd-diagnosis')
r=json.loads((dev/'joint-matrix.json').read_text());build=json.loads((dev/'build.json').read_text());matrix=json.loads((run/'result.json').read_text())
assert r['exit_code']==1 and build['exit_code']==0 and r['source_inventory_sha256']==build['source_inventory_sha256']
rows=[]
for entry in matrix['runs']:
 c=entry['case'];p=run/(entry['mode']+'-'+c)
 ledger=json.loads((p/'postgres-final-ledger.log').read_text());events=json.loads((p/'receiver-events.json').read_text());receipt=json.loads((run/'receipts'/(entry['mode']+'-'+c+'.json')).read_text())
 assert receipt['source_inventory_sha256']==r['source_inventory_sha256']
 rows.append(dict(mode=entry['mode'],case=c,exit_code=entry['exit_code'],elapsed_seconds=receipt['elapsed_seconds'],source_inventory_sha256=receipt['source_inventory_sha256'],receiver_target_accepts=sum(x['kind']=='accept' and x.get('port') in (80,443) for x in events),receiver_gets=sum(x['kind']=='get' for x in events),global_in_use=[b['in_use'] for b in ledger['budgets'] if b['kind']=='global'],reservations=[{k:q[k] for k in ['reservation_state','released_at','termination_receipt_id']} for q in ledger['reservations']],runs=[{k:v[k] for k in ['attempt_state','physical_release_confirmed_at','http_status','success','failure_code','result_commit_id']} for v in ledger['runs']],signed_receipt_file=(p/'run-0-termination-receipt.json').exists(),trace_file=(p/'run-0-probe.trace').exists()))
assert len(rows)==9 and sum(x['exit_code']==0 for x in rows)==8 and rows[-1]['case']=='permit-missing' and rows[-1]['exit_code']==1
(out/'case-summary.json').write_text(json.dumps(dict(head=head,dirty=True,tested_source_inventory_sha256=r['source_inventory_sha256'],planned_cases=46,passed=8,failed=1,unexecuted=37,race_cases_executed=0,complete=False,cases=rows),indent=2)+'\n')
# Preserve exact original calls, process identity and hash, not only a paraphrase.
old=Path('/private/tmp/devpilot-joint63-repair-matrix/normal-allow-https')
trace=old/'run-0-probe.trace';lines=trace.read_text().splitlines()
origin=dict(trace_path=str(trace),trace_sha256=hashof(trace),calls=[dict(line=i+1,text=line) for i,line in enumerate(lines) if 'nscd/socket' in line],process_snapshot=json.loads((old/'run-0-proc-snapshot-1.json').read_text()),python_stack_captured_in_original_run=False,native_libc_stack_captured=False)
(out/'original-nscd-calls.json').write_text(json.dumps(origin,indent=2)+'\n')
# Compare only this authorized repair against the prior preserved failure draft.
previous=Path('/private/tmp/devpilot-joint63-repair-failed-856cbbd/full-draft.diff').read_text()
previous_new={}
for block in previous.split('diff --git ')[1:]:
 ls=block.splitlines();name=ls[0].split(' b/',1)[1]
 if 'new file mode ' in block:previous_new[name]=''.join(l[1:]+'\n' for l in ls if l.startswith('+') and not l.startswith('+++'))
focus=['tests/scheduler/joint_init.py','tests/scheduler/joint_bootstrap.py','tests/scheduler/check-nscd-source.py','tests/scheduler/run-joint63.py']
patch=''.join(''.join(difflib.unified_diff(previous_new.get(n,'').splitlines(True),(repo/n).read_text().splitlines(True),fromfile='prior-failed-draft/'+n,tofile='nscd-repair/'+n)) for n in focus)
(out/'nscd-only.diff').write_text(patch)
old_inventory=json.loads(Path('/private/tmp/devpilot-joint63-repair-development/joint-matrix.json').read_text())['sources']
changed=[n for n,h in old_inventory.items() if (repo/n).is_file() and hashof(repo/n)!=h]
new=sorted(set(r['sources'])-set(old_inventory))
protected=[]
for n in subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines():
 if n.endswith('.sql') or n in ['internal/monitoring/'+f for f in ['executor.go','dns.go','policy.go','admission.go','result.go']] or n in ['tests/scheduler/termination_init.py','tests/scheduler/termination_fixture.py','internal/monitoring/execution_network_test.go'] or n.startswith('tests/network/'):
  b=subprocess.check_output(['git','show','HEAD:'+n],cwd=repo);assert b==(repo/n).read_bytes(),n
  protected.append(dict(path=n,sha256=hashof(repo/n),equals_head=True))
assert hashof(repo/'tests/scheduler/joint_fixture.py')==old_inventory['tests/scheduler/joint_fixture.py'],'connect audit changed'
(out/'unchanged-boundaries.json').write_text(json.dumps(dict(compared_to_failed_source='9008c5c7e580cc80f9875463479155a269bc30ac0fff70a2bf46ce61a88bd704',changed=changed,new=new,connect_audit_unchanged=True,protected_files=protected),indent=2)+'\n')
text='''

## Authorized NSCD-only diagnosis and repair — stopped on ninth case (2026-10-23)

Status remains **28/47;6.3 unchecked**. User authorized only diagnosis/minimal
repair of the two NSCD connects and a from-the-first-case complete rerun, with
**any failure stopping**. No further functional edits or runtime tests followed
the ninth-case failure. All code remains uncommitted/unpushed on reviewed HEAD
`856cbbd45aa19297e4694f7b90b2b44261049b42`.

### Original calls and deterministic attribution

The preserved original `run-0-probe.trace` lines72/74 show PID/TID10, the Python
relay (PPid7, TracerPid7; its Go child11 is created later), making exactly two:
`connect(3,{sa_family=AF_UNIX,sun_path="/var/run/nscd/socket"},110)=-1 ENOENT`.
The original trace has no native/Python call stack; that historical capture
limit remains. Its exact bytes and /proc snapshot are in
`original-nscd-calls.json` and the unchanged previous negative evidence archive.

New deterministic controls use the same immutable fixture image
`sha256:60a78b61cd1378bdb343af6bf6321f383a33f64737c54852a2d462cdfc1df15c`,
Python3.13.5, glibc2.41, UID65534/caps0/no_new_privs, network none, read-only
root, clean LANG/LC_ALL/TZ environment with no HOME. Actual strace captures all
network syscalls and operation markers. Results:

| Real Linux control | Observed connections |
| --- | --- |
| Original default interpreter startup plus actual relay imports | Two AF_UNIX NSCD ENOENT calls, before the first relay-body marker |
| Same interpreter/imports with `-S` | Zero socket and zero connect syscalls |
| `-S`, then explicit `site.main()` with an observing pwd wrapper | Two calls strictly between NSS_BEGIN/NSS_END; actual Python stack: site.main → addusersitepackages → getusersitepackages → getuserbase → _getuserbase/joinuser → posixpath.expanduser → pwd.getpwuid(65534) |
| `-S`, then direct ctypes call to the runtime libc.getpwuid | Two calls strictly between LIBC_GETPWUID_BEGIN/END, both AF_UNIX NSCD ENOENT |

This identifies the unnecessary Python site user-base/passwd query, with
underlying glibc NSS behavior, rather than guessing from a socket path. Original
native C frames and which internal glibc helper made each attempt were not
captured; no claim about those unobserved frames is made. The wrappers are only
in the separate diagnostic positive control, never in Probe acceptance code.
Those controls intentionally attempt absent NSCD in network-none isolation;
they are not newly allowed Probe destinations or audit exceptions.

### Minimal repair and unchanged boundaries

Only the fixture relay interpreter adds `-S`; its source asserts
`sys.flags.no_site==1` and no imported site module. It needs only the standard
library and no user site packages. No arbitrary HOME, custom resolver, DNS stub,
TLS bypass, libc interception or relaxed audit is used. New
`check-nscd-source.py` checks the actual launch and actual relay import list,
runs all four real controls and requires zero socket/connect for the repaired
startup. The matrix invokes it before creating any target fixture. It is not a
Mock of PG/Linux/termination.

The accepted repair topology remains: PID1 is untraced; its caps0 child tracer
controls only bootstrap/Probe descendants. Single-use pipes are created after
tracer fork. Original connect audit, PIDFD/reap/receipt assertions and resource
limits are unchanged. Migration1–8, database functions/roles/EXECUTE/ACL, Go
HTTP/DNS/IP/literal dial/TLS/SNI kernel, old network audit whitelist and accepted
6.4/6.5/5.4 sources are byte-checked against the reviewed baseline. No group7 or
HTTP result persistence was introduced. The scoped repair diff is
`nscd-only.diff`; the full existing6.3 draft remains separately reviewable.

### Actual rerun, including new blocking failure

All build and matrix receipts bind the same dirty source inventory SHA256
`e7ef2bb27d920355b3124834900d29f63f0795a6a063412b7b31724d1329c3ae`, HEAD856cbbd.
This is not a commit SHA or a claim of frozen release acceptance. Linux Go1.24.3
build/vet and the selected offline unit normal/race commands exit0 (11.537s).
The four-control NSCD source regression exits0. Exact commands, tool/image/file
hashes and exits are in raw receipts.

`python3 -B tests/scheduler/run-joint63.py --tools
/private/tmp/devpilot-joint63-nscd-tools --evidence
/private/tmp/devpilot-joint63-nscd-matrix` exits1 after124.328s. Matrix order is
unchanged, from its first case: **8 passed,1 failed,37 not run**, zero race cases.
Full PG18 integration/integration-race, original76+5, API zero-target and separate
6.4/6.5/5.4 normal/race suites were not started after the required stop. Old CI
is not substituted for these missing reruns.

Passing real PG18/Linux normal cases: allow-https, tls-stop, tracer-stopped,
tracer-crashed, supervisor-killed, stop-ack-lost, journal-collision, allow-http.
The four confirmable stop cases have complete trace/proof/signature and atomic
PG capacity return; the HTTPS trace is exactly two connects (one real TCP DNS
session with A/AAAA and one literal target), correct TLS/SNI/cert, Header-only
GET and no credentials. The in-flight TLS stop case has actual receiver closure
and independent network/pidfd/reap/retirement proof. HTTP result columns remain
NULL; safe physical return does not complete the Run or manufacture a result.
The four deliberately unconfirmed fault cases have no signed receipt, PG
reservation quarantined, global in_use1 and no release/HTTP result. These eight
cases are partial new evidence, not complete6.3 or schemeA acceptance.

The ninth `normal/permit-missing` fails in host test log redaction:
`joint_fixture.py:82`, `base64.b64decode(v)` raises TypeError on NoneType.
Source inspection shows the denied `jointHandle` returns nil []byte, sent by
`broker.exchange("reply",map[string][]byte{"frame":reply})`; JSON null becomes
None. The redactor blindly assumes every launch/replay/reply value is a base64
string. The failing raw reply line was not persisted because redaction throws
before log append; the exact error and this source path are retained, not a
claim of a separately captured raw payload or a completed denial handshake.
No redactor fix, reinterpretation of null, audit relaxation or retry was applied.

At failure, the independent receiver witnesses only resolver TCP53 with A/AAAA,
zero target80/443 accepts and zero GET. No final child strace was retrieved, so
this failed case is **not** claimed as a complete zero-target-syscall proof.
No target permit/rules, receipt or capacity release was recorded. Actual PG18
ledger: Run started; reservation **reserved/held**, global in_use1, release/
receipt/physical confirmation/HTTP fields NULL. The failure happened before the
explicit quarantine step; it must not be described as committed quarantined.
Cleanup is teardown only, never a termination receipt or DB return. Read-only
post-failure docker inventory confirms zero leftover labeled fixture containers.

### Remaining review gate and preserved history

Current source is intentionally uncommitted; no push/new CI. PR11 staysOpen,
production execution hard closed. Existing Push39885375219 and PR39885379575
success apply only to baseline856cbbd, not this dirty draft. Do not check6.3.
Next independent decision is whether to authorize a strictly typed denied-frame
log/transport correction; it is not silently included in the NSCD repair.

Original PID1/tracer failure, the second NSCD failure, and the separate earlier
5.4 SIGCONT/management timeout (still without proven exact recovery stack) are
retained unchanged. New evidence is separate at
`evidence/joint63-nscd-failure/`; its archive has actual commands, original-call
excerpt, deterministic stack/operation controls, all nine case logs, /proc/
trace/pidfd/wait, network/receiver/signature evidence, PG final ledgers and hashes.
It contains no private signing key. No commit/push/merge/archive/deployment or
production target execution occurred.
'''
p=repo/'tests/scheduler/joint63-blocker.md';p.write_text(p.read_text()+text)
v=repo/'openspec/changes/add-monitor-scheduler-worker/verification.md';s=v.read_text();s=s.replace('## Current status — task6.3 blocked again (2026-10-23)','## Current status — task6.3 blocked after NSCD repair (2026-10-23)',1)
s=s.replace('按再次失败即停要求，已停止开发和运行验收，仅整理原始证据。以下历史记录保留其当时范围。','本次NSCD最小修复和确定性回归已完成，但46项重跑在第9项permit-missing的null帧日志脱敏失败处停止（8通过/1失败/37未运行），未继续Race或历史全量回归。仅整理证据；以下历史记录保留其当时范围。',1)
s=s.replace('- 当前26/47项已验收：','- 当时26/47项已验收：',1)
s+='\n\n## Task6.3 NSCD-only diagnosis/repair — ninth-case failure, stopped\n'+text
v.write_text(s)
(out/'README.md').write_text('# NSCD-only repair: stopped review handoff\n'+text+'\n\n## Index\n\n- nscd-only.diff: only the latest authorized runtime/diagnostic changes.\n- case-summary.json: each actual outcome, DB release/HTTP distinction.\n- original-nscd-calls.json: original trace hash/calls and actual process snapshot.\n- unchanged-boundaries.json: byte checks and unchanged complete connect audit.\n- raw/: full command receipts, diagnoses and matrix evidence.\n')
(out/'raw').mkdir(exist_ok=True)
for p in [dev,diag,run]:shutil.copytree(p,out/'raw'/p.name,dirs_exist_ok=True)
for n in ['joint63-blocker.md'] :shutil.copy2(repo/'tests/scheduler'/n,out/n)
shutil.copy2(v,out/'verification.md')
tracked=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=repo);full=bytearray(tracked)
for n in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().split('\0'):
 if n and '/evidence/' not in n:full.extend(subprocess.run(['git','diff','--no-index','--binary','/dev/null',n],cwd=repo,stdout=subprocess.PIPE).stdout)
(out/'full-draft.diff').write_bytes(full)
print(json.dumps(dict(head=head,source=r['source_inventory_sha256'],passed=8,failed=1,unexecuted=37,minimal_diff_bytes=len(patch),review_dir=str(out),protected_unchanged=len(protected))))
