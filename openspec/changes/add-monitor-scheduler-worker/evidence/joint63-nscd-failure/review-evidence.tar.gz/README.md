# NSCD-only repair: stopped review handoff


## Authorized NSCD-only diagnosis and repair — stopped on ninth case (2026-10-23)

Status remains **28/47;6.3 unchecked**. User authorized only diagnosis/minimal
repair of the two NSCD connects and a from-the-first-case complete rerun, with
**any failure stopping**. No further functional edits or runtime tests followed
the ninth-case failure. All code remains uncommitted/unpushed on reviewed HEAD
`856cbbd45aa19297e4694f7b90b2b44261049b42`.

### Original calls and deterministic attribution

The preserved original `run-0-probe.trace` lines72/74 show PID/TID10, the Python
relay (PPid7, TracerPid7; its Go child11 is created later), making exactly two:
`connect(3,{sa_family=AF_UNIX,sun_path="/var/run/nscd/socket"},110)=-1 ENOENT`.
The original trace has no native/Python call stack; that historical capture
limit remains. Its exact bytes and /proc snapshot are in
`original-nscd-calls.json` and the unchanged previous negative evidence archive.

New deterministic controls use the same immutable fixture image
`sha256:60a78b61cd1378bdb343af6bf6321f383a33f64737c54852a2d462cdfc1df15c`,
Python3.13.5, glibc2.41, UID65534/caps0/no_new_privs, network none, read-only
root, clean LANG/LC_ALL/TZ environment with no HOME. Actual strace captures all
network syscalls and operation markers. Results:

| Real Linux control | Observed connections |
| --- | --- |
| Original default interpreter startup plus actual relay imports | Two AF_UNIX NSCD ENOENT calls, before the first relay-body marker |
| Same interpreter/imports with `-S` | Zero socket and zero connect syscalls |
| `-S`, then explicit `site.main()` with an observing pwd wrapper | Two calls strictly between NSS_BEGIN/NSS_END; actual Python stack: site.main → addusersitepackages → getusersitepackages → getuserbase → _getuserbase/joinuser → posixpath.expanduser → pwd.getpwuid(65534) |
| `-S`, then direct ctypes call to the runtime libc.getpwuid | Two calls strictly between LIBC_GETPWUID_BEGIN/END, both AF_UNIX NSCD ENOENT |

This identifies the unnecessary Python site user-base/passwd query, with
underlying glibc NSS behavior, rather than guessing from a socket path. Original
native C frames and which internal glibc helper made each attempt were not
captured; no claim about those unobserved frames is made. The wrappers are only
in the separate diagnostic positive control, never in Probe acceptance code.
Those controls intentionally attempt absent NSCD in network-none isolation;
they are not newly allowed Probe destinations or audit exceptions.

### Minimal repair and unchanged boundaries

Only the fixture relay interpreter adds `-S`; its source asserts
`sys.flags.no_site==1` and no imported site module. It needs only the standard
library and no user site packages. No arbitrary HOME, custom resolver, DNS stub,
TLS bypass, libc interception or relaxed audit is used. New
`check-nscd-source.py` checks the actual launch and actual relay import list,
runs all four real controls and requires zero socket/connect for the repaired
startup. The matrix invokes it before creating any target fixture. It is not a
Mock of PG/Linux/termination.

The accepted repair topology remains: PID1 is untraced; its caps0 child tracer
controls only bootstrap/Probe descendants. Single-use pipes are created after
tracer fork. Original connect audit, PIDFD/reap/receipt assertions and resource
limits are unchanged. Migration1–8, database functions/roles/EXECUTE/ACL, Go
HTTP/DNS/IP/literal dial/TLS/SNI kernel and old network audit whitelist are byte-checked against the
reviewed baseline, together with the protected6.4/6.5/5.4 files listed in
unchanged-boundaries.json. The shared network_fixture.py retains its earlier
unaccepted6.3 adapter changes, but is unchanged by this NSCD-only repair. No group7 or
HTTP result persistence was introduced. The scoped repair diff is
`nscd-only.diff`; the full existing6.3 draft remains separately reviewable.

### Actual rerun, including new blocking failure

All build and matrix receipts bind the same dirty source inventory SHA256
`e7ef2bb27d920355b3124834900d29f63f0795a6a063412b7b31724d1329c3ae`, HEAD856cbbd.
This is not a commit SHA or a claim of frozen release acceptance. Linux Go1.24.3
build/vet and the selected offline unit normal/race commands exit0 (11.537s).
The four-control NSCD source regression exits0. Exact commands, tool/image/file
hashes and exits are in raw receipts.

`python3 -B tests/scheduler/run-joint63.py --tools
/private/tmp/devpilot-joint63-nscd-tools --evidence
/private/tmp/devpilot-joint63-nscd-matrix` exits1 after124.328s. Matrix order is
unchanged, from its first case: **8 passed,1 failed,37 not run**, zero race cases.
Full PG18 integration/integration-race, original76+5, API zero-target and separate
6.4/6.5/5.4 normal/race suites were not started after the required stop. Old CI
is not substituted for these missing reruns.

Passing real PG18/Linux normal cases: allow-https, tls-stop, tracer-stopped,
tracer-crashed, supervisor-killed, stop-ack-lost, journal-collision, allow-http.
The four confirmable stop cases have complete trace/proof/signature and atomic
PG capacity return; the HTTPS trace is exactly two connects (one real TCP DNS
session with A/AAAA and one literal target), correct TLS/SNI/cert, Header-only
GET and no credentials. The in-flight TLS stop case has actual receiver closure
and independent network/pidfd/reap/retirement proof. HTTP result columns remain
NULL; safe physical return does not complete the Run or manufacture a result.
The four deliberately unconfirmed fault cases have no signed receipt, PG
reservation quarantined, global in_use1 and no release/HTTP result. These eight
cases are partial new evidence, not complete6.3 or schemeA acceptance.

The ninth `normal/permit-missing` fails in host test log redaction:
`joint_fixture.py:82`, `base64.b64decode(v)` raises TypeError on NoneType.
Source inspection shows the denied `jointHandle` returns nil []byte, sent by
`broker.exchange("reply",map[string][]byte{"frame":reply})`; JSON null becomes
None. The redactor blindly assumes every launch/replay/reply value is a base64
string. The failing raw reply line was not persisted because redaction throws
before log append; the exact error and this source path are retained, not a
claim of a separately captured raw payload or a completed denial handshake.
No redactor fix, reinterpretation of null, audit relaxation or retry was applied.

At failure, the independent receiver witnesses only resolver TCP53 with A/AAAA,
zero target80/443 accepts and zero GET. No final child strace was retrieved, so
this failed case is **not** claimed as a complete zero-target-syscall proof.
No installed target permit/rules, receipt or capacity release was recorded. Actual PG18
ledger: Run started; reservation **reserved/held**, global in_use1, release/
receipt/physical confirmation/HTTP fields NULL. The failure happened before the
explicit quarantine step; it must not be described as committed quarantined.
Cleanup is teardown only, never a termination receipt or DB return. Read-only
post-failure docker inventory confirms zero leftover labeled fixture containers.

### Remaining review gate and preserved history

Current source is intentionally uncommitted; no push/new CI. PR11 staysOpen,
production execution hard closed. Existing Push39885375219 and PR39885379575
success apply only to baseline856cbbd, not this dirty draft. Do not check6.3.
Next independent decision is whether to authorize a strictly typed denied-frame
log/transport correction; it is not silently included in the NSCD repair.

Original PID1/tracer failure, the second NSCD failure, and the separate earlier
5.4 SIGCONT/management timeout (still without proven exact recovery stack) are
retained unchanged. New evidence is separate at
`evidence/joint63-nscd-failure/`; its archive has actual commands, original-call
excerpt, deterministic stack/operation controls, all nine case logs, /proc/
trace/pidfd/wait, network/receiver/signature evidence, PG final ledgers and hashes.
It contains no private signing key. No commit/push/merge/archive/deployment or
production target execution occurred.


## Index

- nscd-only.diff: only the latest authorized runtime/diagnostic changes.
- case-summary.json: each actual outcome, DB release/HTTP distinction.
- original-nscd-calls.json: original trace hash/calls and actual process snapshot.
- unchanged-boundaries.json: byte checks and unchanged complete connect audit.
- raw/: full command receipts, diagnoses and matrix evidence.
