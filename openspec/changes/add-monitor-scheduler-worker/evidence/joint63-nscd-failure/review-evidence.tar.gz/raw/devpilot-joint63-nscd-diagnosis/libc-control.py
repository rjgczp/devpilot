import subprocess,json,pathlib
source="""import ctypes,os,json
libc=ctypes.CDLL(None,use_errno=True)
libc.getpwuid.argtypes=[ctypes.c_uint];libc.getpwuid.restype=ctypes.c_void_p
print('LIBC_GETPWUID_BEGIN',os.getpid(),flush=True)
assert libc.getpwuid(os.getuid())
print('LIBC_GETPWUID_END',flush=True)
"""
cmd=['/usr/bin/strace','-f','-ttt','-e','trace=network,write,execve','-o','/tmp/libc.trace','/usr/bin/python3','-S','-u','-c',source]
p=subprocess.run(cmd,env={'LANG':'C','LC_ALL':'C','TZ':'UTC'},capture_output=True,text=True,timeout=8)
assert p.returncode==0,(p.returncode,p.stderr)
print(json.dumps(dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,trace=pathlib.Path('/tmp/libc.trace').read_text())))
