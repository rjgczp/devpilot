import json,os,pathlib,subprocess,sys
# Isolated negative controls deliberately exercise NSS, never real target networking.
common="import base64,fcntl,json,os,select,subprocess,sys,time\nprint('relay_imports_complete',flush=True)\n"
profile="""import sys,pwd,traceback,os,json
real=pwd.getpwuid
def observe(uid):
 print('NSS_BEGIN '+json.dumps(dict(pid=os.getpid(),uid=uid,stack=traceback.format_stack(limit=12))),flush=True)
 try:return real(uid)
 finally:print('NSS_END',flush=True)
pwd.getpwuid=observe
print('BEFORE_SITE_MAIN',flush=True)
import site
site.main()
print('AFTER_SITE_MAIN',flush=True)
"""
results=[]
for name,args,source in [('original-startup',[],common),('no-site-startup',['-S'],common),('explicit-site',['-S'],profile)]:
 path='/tmp/'+name+'.trace'
 cmd=['/usr/bin/strace','-f','-ttt','-e','trace=network,write,execve','-o',path,'/usr/bin/python3',*args,'-u','-c',source]
 p=subprocess.run(cmd,env={'LANG':'C','LC_ALL':'C','TZ':'UTC'},capture_output=True,text=True,timeout=8)
 assert p.returncode==0,(name,p.returncode,p.stderr)
 results.append(dict(name=name,command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,trace=pathlib.Path(path).read_text()))
print(json.dumps(dict(uid=os.getuid(),status=pathlib.Path('/proc/self/status').read_text(),python=sys.version,libc=subprocess.check_output(['ldd','--version'],text=True),nsswitch=pathlib.Path('/etc/nsswitch.conf').read_text(),site_source=pathlib.Path('/usr/lib/python3.13/site.py').read_text(),results=results)))
