import subprocess,json,pathlib,os,uuid,datetime
out=pathlib.Path('/private/tmp/devpilot-joint63-blocked-856cbbd');prefix='devpilot-n64-8c1e38ab91';pg=prefix+'-pg';life=prefix+'-run-0-joint'
def run(name,cmd,timeout=5):
 r=subprocess.run(cmd,capture_output=True,timeout=timeout);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);(out/(name+'.json')).write_text(json.dumps(dict(command=cmd,exit_code=r.returncode,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),cleanup_only=True,termination_receipt=False),indent=2)+'\n');return r
for name in [pg,life]:
 j=json.loads(subprocess.check_output(['docker','inspect',name]))[0];assert j['Config']['Labels']['devpilot.disposable.network64']==prefix and j['HostConfig']['NetworkMode']=='none' if name==pg else j['Config']['Labels']['devpilot.disposable.network64']==prefix
check=subprocess.check_output(['docker','exec',pg,'psql','-U','devpilot_fixture','-d','devpilot_registration_test','-At','-c',"SELECT current_setting('cluster_name')||':'||current_setting('server_version_num')"]).decode().strip();assert check.startswith('devpilot-budget-disposable:18')
ledger=json.loads((out/'live-pg-held-ledger.stdout').read_text());r=ledger['runs'][0]
inc=subprocess.check_output(['docker','exec',pg,'psql','-U','devpilot_fixture','-d','devpilot_registration_test','-At','-c',"SELECT incarnation::text FROM scheduler_control WHERE kind='controller' AND login_name='scheduler_budget_controller'"]).decode().strip()
ids=[inc]+[r[k] for k in ['workspace_id','project_id','monitor_id','run_id']]
for v in ids:assert str(uuid.UUID(v))==v
sql="BEGIN ISOLATION LEVEL READ COMMITTED; SELECT session_user,current_user; SELECT scheduler_private.quarantine_physical("+','.join("'"+x+"'::uuid" for x in ids)+','+str(int(r['fencing_token']))+'::bigint); COMMIT;'
q=run('existing-controller-quarantine',['docker','exec','-e','PGPASSWORD=disposable_fixture_only',pg,'psql','-h','127.0.0.1','-U','scheduler_budget_controller','-d','devpilot_registration_test','-v','ON_ERROR_STOP=1','-c',sql]);assert q.returncode==0
# Preserve the original ledger and a separate post-quarantine snapshot. The
# narrow function NEVER releases or alters the network result.
checksql="SELECT jsonb_build_object('budgets',(SELECT jsonb_agg(to_jsonb(b)) FROM scheduler_budget_state b),'runs',(SELECT jsonb_agg(to_jsonb(r)) FROM monitor_runs r),'reservations',(SELECT jsonb_agg(to_jsonb(q)) FROM scheduler_reservations q))"
a=run('post-quarantine-ledger',['docker','exec',pg,'psql','-U','devpilot_fixture','-d','devpilot_registration_test','-At','-c',checksql]);assert a.returncode==0
j=json.loads(a.stdout);assert j['reservations'][0]['reservation_state']=='quarantined' and j['reservations'][0]['termination_receipt_id'] is None and j['runs'][0]['http_status'] is None and next(x for x in j['budgets'] if x['kind']=='global')['in_use']==1
# A single cleanup action using only the existing lifecycle KILL capability.
# No ptrace/admin privilege, host PID, namespace replacement, or DB release.
code="""import pathlib,os,signal,json
fields=dict((k,v.strip()) for l in pathlib.Path('/proc/1/status').read_text().splitlines() if ':' in l for k,v in [l.split(':',1)])
pid=int(fields['TracerPid']);assert pid>1 and fields['Name']=='python3' and fields['State'].startswith('t')
s=dict((k,v.strip()) for l in pathlib.Path('/proc/'+str(pid)+'/status').read_text().splitlines() if ':' in l for k,v in [l.split(':',1)])
assert s['Name']=='strace' and s['State'].startswith('T') and s['Uid'].split()[0]=='0'
print(json.dumps(dict(cleanup_only=True,tracee=1,tracer=pid,signal='SIGKILL',attestation=False)),flush=True)
os.kill(pid,signal.SIGKILL)
"""
run('single-tracer-cleanup',['docker','exec',life,'python3','-c',code])
print('Existing real Controller quarantined Run without releasing any slot; one owned-tracer cleanup action recorded.')
