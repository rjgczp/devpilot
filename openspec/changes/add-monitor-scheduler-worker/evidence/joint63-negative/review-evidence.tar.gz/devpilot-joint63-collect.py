import subprocess,json,pathlib,hashlib,datetime
out=pathlib.Path('/private/tmp/devpilot-joint63-blocked-856cbbd');prefix='devpilot-n64-8c1e38ab91'
def capture(name,cmd,timeout=5):
 r=subprocess.run(cmd,capture_output=True,timeout=timeout)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 (out/(name+'.json')).write_text(json.dumps(dict(command=cmd,exit_code=r.returncode,at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
 return r
ids=subprocess.check_output(['docker','ps','-aq','--filter','label=devpilot.disposable.network64='+prefix],text=True).split()
for cid in ids:
 j=json.loads(subprocess.check_output(['docker','inspect',cid]))[0];assert j['Config']['Labels']['devpilot.disposable.network64']==prefix
 name=j['Name'].lstrip('/');(out/(name+'-inspect.json')).write_text(json.dumps(j,indent=2)+'\n')
 if name.endswith('-joint'):
  capture('hung-top',['docker','top',cid,'-eo','pid,ppid,stat,wchan:30,comm'])
  code="""import os,json,pathlib
rows=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:
  fields=dict((k,v.strip()) for l in (p/'status').read_text().splitlines() if ':' in l for k,v in [l.split(':',1)])
  row=dict(pid=int(p.name),status={k:fields[k] for k in ('Name','State','PPid','TracerPid','Uid','Gid','CapEff','NoNewPrivs')},wchan=(p/'wchan').read_text(),stat=(p/'stat').read_text())
  try:row['fds']={f.name:os.readlink(f) for f in (p/'fd').iterdir()}
  except PermissionError:row['fds']='permission denied'
  rows.append(row)
 except FileNotFoundError:pass
print(json.dumps(rows))"""
  capture('hung-processes',['docker','exec',cid,'python3','-c',code])
  capture('hung-trace',['docker','exec',cid,'cat','/tmp/probe.trace'])
 if name.endswith('-pg'):
  sql="SELECT jsonb_build_object('cluster',current_setting('cluster_name'),'version',current_setting('server_version'),'at',clock_timestamp(),'budgets',(SELECT jsonb_agg(to_jsonb(b)) FROM scheduler_budget_state b),'runs',(SELECT jsonb_agg(to_jsonb(r)) FROM monitor_runs r),'reservations',(SELECT jsonb_agg(to_jsonb(q)) FROM scheduler_reservations q),'locks',(SELECT jsonb_agg(to_jsonb(l)) FROM pg_locks l),'activity',(SELECT jsonb_agg(jsonb_build_object('pid',pid,'user',usename,'xact_start',xact_start,'state',state,'wait',wait_event,'blockers',pg_blocking_pids(pid))) FROM pg_stat_activity WHERE datname=current_database()))"
  capture('live-pg-held-ledger',['docker','exec',cid,'psql','-U','devpilot_fixture','-d','devpilot_registration_test','-At','-c',sql])
print('Read-only evidence captured for',len(ids),'owned fixture containers')
