# Task6.3 joint acceptance — stopped, not accepted

Reviewed baseline and current Git HEAD:
`856cbbd45aa19297e4694f7b90b2b44261049b42`.
Push39885375219 and PR39885379575 were completed/success, with verify,
integration and execution-security all success, before any task6.3 development.
All current6.3 source changes are an **uncommitted review draft**. They were not
pushed or made an accepted release. Task6.3 remains unchecked; progress28/47.

## Attempted integration and exact observed limits

The fixture-only command reuses the original private engine without changing
executor.go, dns.go, policy.go, TLS/HTTP handling, single-process admission or
budgets. A separately selected TCP-only process seal retains the offline Seal
entry's deny-all mode. The original verified database functions, role/EXECUTE
ACLs and Migration1–8 are unchanged. The new outer adapter uses the existing
6.5 stop helper definitions, public fixture OS CA trust and no-upstream per-Run
namespaces. Start/input/target commits precede their respective pipe/rule steps;
no business connection is held during the outer management calls.

The first Linux build/vet and normal/race binary compilation succeeded, but
**full normal/race joint acceptance did not pass**. Build source078d37d... and
subsequent dirty test source hashes differ; neither is claimed as a frozen
implementation SHA. Actual full hashes/commands/exits are in command receipts.
No old CI result is attributed to the uncommitted source.

| Evidence directory under /private/tmp | Command receipt | Actual outcome |
| --- | --- | --- |
| devpilot-joint63-https-smoke | devpilot-joint63-development/https-smoke.json | exit1, before Probe input: Docker Mounts excludes tmpfs; assertion mistakenly expected four Mounts instead of two read-only binds plus two HostConfig.Tmpfs entries |
| devpilot-joint63-https-mount-corrected | devpilot-joint63-development/https-mount-corrected.json | exit1, original3s management wait expired after complete A/AAAA, zero target TCP/GET; no target reservation, receipt or release |
| devpilot-joint63-https-tracer-corrected | devpilot-joint63-development/https-tracer-corrected.json | exit1, actual original-kernel HTTPS GET/200 in memory, then independent process termination/cleanup blocked; no signed receipt or release |

The two read-only bind mounts are the fixture Go binary and a public fixture CA
in the system trust directory, not a config/DB/secret/management volume.
Credential/environment/cgroup/FD checks returned UID/GID65534, caps0,
no_new_privs, all-thread seccomp,128MiB/CPU1/PID128/FD256, read-only root and
TCP-only socket creation. These observations are **partial evidence**, not a
substitute for the full acceptance or a production permission.

## First new timeout: anonymous-pipe EOF and tracer FD inheritance

An unprivileged no-network diagnostic showed that strace retained the inherited
pipe writer after its tracee closed that writer. The read side received the
frame but not EOF. The existing target protocol intentionally requires exact
frame plus EOF; that requirement was not removed or relaxed. Diagnostic output
has `eof_available_after_tracee_closed=false` and the tracer's retained pipe FD.
This proves the instrumentation defect class; the failed run did not capture
its own blocked read syscall, so its exact wait stack is not asserted as a
separately captured trace. Original3s/2s/35s/45s budgets were not extended.

A bounded daemonized-strace capability check succeeded with no additional
capabilities and python retaining PID1. Moving that tracer before pipe creation
allowed the real DNS → PG target commit → two-rule confirmation → literal TLS
connection → GET flow, but introduced the separate physical-stop defect below.
The successful capability check did not prove that this placement could stop.

## Blocking physical-stop defect: tracing the stop authority itself

The new tracer placement traced PID1 as well as the Probe. The existing stop
helper enumerates every same-Run descendant and sends SIGSTOP before SIGKILL.
It therefore stopped the tracer responsible for letting PID1 progress.

Actual read-only capture after failure:

- PID1 `python3`: State `t (tracing stop)`, TracerPid10.
- PID10 `strace`: State `T (stopped)`, PPid1.
- PID11 original Go Probe: UID65534/caps0, alive/sleeping, TracerPid10.
- Saved syscall trace ends at PID1 `pidfd_send_signal(3, SIGSTOP, NULL, 0`.
- Docker top reports PID1 `ptrace_stop` and tracer `do_signal_stop`.
- Both independent Run/Gateway revocations succeeded, veth removed,
  conntrack empty. Full process/PIDFD/retirement proof did not complete.
- Ordinary cleanup's docker rm failed with “could not kill container ... did
  not receive an exit event”. The final cleanup exception masked the preceding
  bounded management confirmation failure; both levels are retained.

This is sufficient to reject this **new tracing topology**. No signature,
process-exit guess, lease expiry, pending Docker kill or container deletion was
accepted as a termination receipt. No accept_termination/reconcile release call
ran for this Run. The previous independently accepted6.5/5.4 source is unchanged.

## Database and containment evidence

Before disposable teardown, actual PG18.6 cluster
`devpilot-budget-disposable` had global in_use1/active_count1, origin/IP slots
held, Run `started`, HTTP status/success/failure/result_commit_id NULL,
physical_release_confirmed_at NULL, reservation `reserved`, receipt/release NULL.
No active Worker/Supervisor transaction or blocker remained. The original
fixture's Go failure cleanup had removed its Controller identity; a separate
conservative quarantine call was refused **before SQL execution** by the UUID
identity guard. No replacement identity/role was created. Precisely: the
reservation remained reserved/held, not a successfully committed `quarantined`
state. The uncertain physical resources were never returned.

After read-only captures, one narrowly scoped cleanup action, with the existing
lifecycle KILL capability, killed only the stopped owned tracer. It returned137
as the already-pending container termination completed. This was teardown only,
not a signed proof or acceptance. The other four exclusively labelled fixture
containers were removed only after rechecking the disposable PG18 marker and
saving the unreleased ledger. Final matching container list was empty. No
Docker restart, host PID namespace, SYS_PTRACE/SYS_ADMIN/NET_RAW increase, DB
permission change, new execution, result write or capacity release was used.

## Required review before resuming this affected acceptance

The instrumentation must have no path in which the stop authority is a tracee
of a process it stops. It must also avoid keeping single-use pipe writers alive
in the tracer. A possible direction is to trace only a separately launched,
unprivileged bootstrap/Probe domain, allocating its anonymous pipes after the
tracer forks; that is **a proposal only**, not implemented or proven here. It
must retain the credential/FD/EOF/timeout boundaries, original kernel,
independent network revoke/pidfd/reap/retirement chain and original capabilities.
No permission expansion, time extension, missing-dependency skip or guessed
receipt is an acceptable remedy.

No more joint test or feature development was started after the physical-stop
failure. Negative cases, race run, IPv6 joint execution and the requested full
regression for this draft remain **unexecuted/not accepted**. The original76,
6.4/6.5/5.4 and API audit results for the reviewed baseline remain historical to
that exact SHA. The earlier5.4 SIGCONT/management timeout remains unresolved in
verification.md; this new diagnosis does not resolve or delete that risk.

Production execution stays hard closed. PR11 stays Open. No merge, Archive,
deployment, production migration or group7 result implementation occurred.
