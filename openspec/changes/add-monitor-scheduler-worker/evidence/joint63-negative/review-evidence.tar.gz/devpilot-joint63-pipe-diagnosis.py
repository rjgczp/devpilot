import os,subprocess,select,json,pathlib,signal
r,w=os.pipe()
cmd=['strace','-f','-e','trace=none','-o','/tmp/trace','python3','-u','-c',"import os,time; os.write("+str(w)+",b'X');os.close("+str(w)+");print('writer_closed',flush=True);time.sleep(5)"]
p=subprocess.Popen(cmd,pass_fds=(w,),stdout=subprocess.PIPE,stderr=subprocess.PIPE);os.close(w)
assert p.stdout.readline()==b'writer_closed\n';assert os.read(r,1)==b'X'
readable=bool(select.select([r],[],[],.1)[0])
writer_links=[]
for fd in pathlib.Path('/proc/'+str(p.pid)+'/fd').iterdir():
 try:
  link=os.readlink(fd)
  if link==os.readlink('/proc/self/fd/'+str(r)):writer_links.append(dict(fd=fd.name,target=link))
 except FileNotFoundError:pass
print(json.dumps(dict(tracer_pid=p.pid,eof_available_after_tracee_closed=readable,tracer_retained_pipe=writer_links)))
assert not readable and writer_links
# Test teardown only, never a termination attestation.
os.kill(p.pid,signal.SIGKILL)
subprocess.run(['pkill','-KILL','-P',str(p.pid)],capture_output=True)
p.wait(timeout=2)
