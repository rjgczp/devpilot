# Stopped task6.3 repair review


## Authorized tracing-only repair and second failed acceptance (2026-10-23)

**Stopped again; uncommitted; task6.3 unchecked;28/47.** The product explicitly
required stopping and retaining the draft on another acceptance failure. No
further runtime tests, fixes, commits or pushes followed this failure.

Compared with the original `pending-review.diff`, the repair restores the
accepted6.5 topology: Python Supervisor PID1 is untraced; its UID65534/caps0
child tracer traces only an unprivileged bootstrap, Probe and descendants.
Anonymous envelope/permit pipes are allocated inside that tracee after tracer
creation so the tracer cannot retain their writers. The original6.5 stop/reap
helpers, pidfd exit requirements and2s/3s/35s/45s budgets are unchanged. New
bounded observations record real /proc states, pidfd signal and waitpid events;
they do not substitute for the original termination proof. See
`tracing-repair.diff` and `topology-comparison.json` in the review bundle.

The old PID1/tracer dependency is directly supported by the saved tracing-stop,
TracerPid10, stopped tracer and incomplete pidfd_send_signal syscall. The exact
kernel wait stack/syscall completion was not captured; this remains a limit.
The separate earlier5.4 SIGCONT/management timeout remains unexplained and its
original evidence/risk is retained.

### Commands and source binding

HEAD remains856cbbd45aa19297e4694f7b90b2b44261049b42, dirty=true.
Actual build and failing matrix source inventory SHA256:
`9008c5c7e580cc80f9875463479155a269bc30ac0fff70a2bf46ce61a88bd704`.
This is a tested dirty source inventory, **not a new commit or accepted SHA**.
Only subsequent documentation/evidence changed after the failure. Complete
commands, file/binary hashes, environment/image metadata and exits are retained
in `raw/devpilot-joint63-repair-development/` and matrix receipts.

- Offline Linux Go1.24.3 build/vet and selected offline unit normal/race: exit0,
  13.546s. No network acceptance is inferred from these results.
- `python3 -B tests/scheduler/run-joint63.py --tools
  /private/tmp/devpilot-joint63-repair-tools --evidence
  /private/tmp/devpilot-joint63-repair-matrix`: exit1,13.824s.
- First case `normal/allow-https` failed the unchanged strict connect audit:
  `(allow-https,4,1)`. Planned23cases ×normal/race=46; **1 failed,45 not run**.
  Stopped/crashed tracer, Supervisor loss, timeout/fault injection and TLS
  in-flight stop cases exist as unaccepted test code, not passing evidence.
- Original76+5, API zero-target and6.4/6.5/5.4 normal/race remain unchanged but
  were not rerun on this draft after the mandatory stop. Baseline green CI is
  not attributed to the draft. OpenSpec/static checks are separate below.

### Actual trace, physical proof and conservative database outcome

The real process snapshot has PID1 TracerPid0, tracer7/UID65534/caps0,
bootstrap10/TracerPid7 and GoProbe11/TracerPid7. Independent fixture records
one TCP resolver session with A/AAAA, one literal TCP443/TLS session, correct
SNI/certificate, one credential-free Header-only GET and immediate client close
after headers while the declared1MiB body is unsent. Original engine result200
exists only in private memory, not in the Run table.

Real stop records show pidfd exits for7/10/11, actual SIGSTOP/SIGKILL and waitpid
for all three, no remaining descendants, independent dual-layer network revoke,
namespace retirement and a signed persisted physical termination receipt.
Read-only OpenSSL verification of that saved Ed25519 signature returned0; proof
hashes match the immutable bundle. This single normal case does not prove the
unexecuted fault/race/in-flight TLS scenarios or complete joint acceptance.

Unlike the first failed topology, a physical receipt **was signed this time**.
The audit failed before its delivery to the Go database consumer. No receipt
was consumed by PG and no capacity was returned: final real PG18 ledger has
reservation `quarantined`, global in_use1, released_at/termination_receipt_id/
physical_release_confirmed_at NULL; Run still started, HTTP status/success/
failure/result_commit_id NULL. A physical receipt is not an HTTP result.
Container cleanup is not used as a release proof.

The four connect calls are two AF_UNIX `/var/run/nscd/socket` ENOENT attempts
from Python bootstrap PID10, plus two Go TCP connects. Receiver evidence
accounts for the latter as one resolver and one target connection. Go sockaddr
pointers are opaque under its non-dumpable seal; the independent receiver is
retained as witness. The exact Python/NSS user-space caller stack was not
captured, so an implicit startup/NSS cause is a hypothesis, not proven detail.
No NSCD exception, relaxed count, ignored syscall or CGO/audit change was made.
Any further bootstrap correction requires renewed review; none was applied.

### Evidence and remaining gate

Original negative archive SHA256 remains
`7777a1924594af454b171d89d00c781f6e4e7b874631ba9d622874eb3bcd25f5`
at `evidence/joint63-negative/`. New failure is separately preserved at
`evidence/joint63-repair-failure/`; raw /proc, strace, pidfd/signal/wait events,
firewall/routes, receiver, signature and PG ledger are in its checksummed
archive. Review directory `/private/tmp/devpilot-joint63-repair-failed-856cbbd`
also includes the focused repair diff and full draft patch. No private signing
key is included. Files remain uncommitted for independent review as requested.

Latest actual remote SHA is still856cbbd; Push39885375219 and PR39885379575 are
completed/success **for that baseline only**. PR11 remainsOpen. No new Actions
run exists for this uncommitted draft. Migration1–8, DB ACL/functions, original
HTTP/DNS/IP/TLS kernel and accepted6.4/6.5/5.4 source are unchanged. Production
execution stays hard disabled; no group7/result persistence was implemented.


## Review index

- tracing-repair.diff: topology fix vs original pending draft, not accepted.
- full-draft.diff: complete text/source pending patch vs HEAD; binary evidence separate.
- raw/: unchanged actual command receipts, failed normal matrix and evidence.
- offline-signature-check.json: read-only check, not a test rerun or DB consumption.
- unchanged-protected-files.json: exact HEAD byte comparison.
- baseline-ci.json/pr-state.json: actual GitHub metadata, baseline only.
