from pathlib import Path
import json,subprocess,uuid,time,select,os
out=Path('/private/tmp/devpilot-release54-signal-diagnosis');out.mkdir(exist_ok=False)
records=[]
for handler in [False,True]:
 name='devpilot-signal54-'+uuid.uuid4().hex[:10]
 source="import signal,time,os,json\n"+("signal.signal(signal.SIGCONT,lambda *_:print('continued',flush=True))\n" if handler else '')+"print(json.dumps(dict(pid=os.getpid(),handler=str(signal.getsignal(signal.SIGCONT)))),flush=True)\nwhile True:time.sleep(.05)"
 cmd=['docker','run','--rm','--name',name,'--label','devpilot.disposable.signal54='+name,'--network','none','--cap-drop','ALL','--security-opt','no-new-privileges:true','--read-only','--memory=128m','--cpus=1','--pids-limit=128','--ulimit','nofile=256:256','--entrypoint','python3','devpilot-scheduler-fixture','-u','-c',source]
 p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  assert select.select([p.stdout],[],[],3)[0];ready=json.loads(p.stdout.readline());assert ready['pid']==1
  subprocess.run(['docker','kill','--signal','STOP',name],check=True,capture_output=True)
  def state():
   return subprocess.check_output(['docker','exec',name,'python3','-c',"import pathlib;print(next(x for x in pathlib.Path('/proc/1/status').read_text().splitlines() if x.startswith('State:')))"] ,text=True).strip()
  stopped=state();assert 'T (stopped)' in stopped
  subprocess.run(['docker','kill','--signal','CONT',name],check=True,capture_output=True)
  after=state();row=dict(handler_installed=handler,ready=ready,state_after_STOP=stopped,state_after_CONT=after,command=cmd)
  if handler:
   assert 'T (stopped)' not in after
   assert select.select([p.stdout],[],[],1)[0] and p.stdout.readline().strip()==b'continued'
  else:assert 'T (stopped)' in after
  records.append(row)
 finally:
  d=json.loads(subprocess.check_output(['docker','inspect',name]))[0];assert d['Config']['Labels']['devpilot.disposable.signal54']==name and d['HostConfig']['NetworkMode']=='none' and d['HostConfig']['CapDrop']==['ALL']
  subprocess.run(['docker','rm','-f','-v',name],check=True,capture_output=True);p.wait(timeout=3)
(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
print('Real Linux PID1: default SIGCONT remained stopped; explicit SIGCONT handler resumed. No Probe/network/DB/Run or physical release involved.')
