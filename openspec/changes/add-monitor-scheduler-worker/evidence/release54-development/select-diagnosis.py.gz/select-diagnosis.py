from pathlib import Path
import subprocess,json,time,select,uuid,os
out=Path('/private/tmp/devpilot-release54-select-diagnosis');out.mkdir(exist_ok=False);name='devpilot-select54-'+uuid.uuid4().hex[:8]
source="import sys,select,time,json,os\nprint('ready',flush=True)\nsys.stdin.readline()\nstart=time.monotonic();print('select-enter',flush=True)\nr=select.select([sys.stdin],[],[],.8)[0]\nprint(json.dumps(dict(elapsed=time.monotonic()-start,readable=bool(r))),flush=True)\nif r:sys.stdin.readline()"
cmd=['docker','run','--rm','-i','--name',name,'--label','devpilot.disposable.select54='+name,'--network','none','--cap-drop','ALL','--security-opt','no-new-privileges:true','--read-only','--memory=128m','--cpus=1','--pids-limit=128','--ulimit','nofile=256:256','--entrypoint','python3','devpilot-scheduler-fixture','-u','-c',source]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:
 assert select.select([p.stdout],[],[],3)[0] and p.stdout.readline().strip()==b'ready'
 p.stdin.write(b'begin\n');p.stdin.flush();assert p.stdout.readline().strip()==b'select-enter'
 subprocess.run(['docker','kill','--signal','STOP',name],check=True,capture_output=True)
 time.sleep(1.1)
 subprocess.run(['docker','kill','--signal','CONT',name],check=True,capture_output=True)
 stalled=not bool(select.select([p.stdout],[],[],.1)[0])
 p.stdin.write(b'explicit-stop-control\n');p.stdin.flush()
 assert select.select([p.stdout],[],[],.5)[0];answer=json.loads(p.stdout.readline());code=p.wait(timeout=3)
 record=dict(command=cmd,suspended_seconds=1.1,select_original_timeout_seconds=.8,no_reply_after_CONT=stalled,explicit_control_reply=answer,exit_code=code)
 (out/'results.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
 assert stalled and answer['readable'] and answer['elapsed']>1.1 and code==0
finally:
 d=subprocess.run(['docker','inspect',name],capture_output=True)
 if d.returncode==0:
  row=json.loads(d.stdout)[0];assert row['Config']['Labels']['devpilot.disposable.select54']==name
  subprocess.run(['docker','rm','-f','-v',name],check=True,capture_output=True)
